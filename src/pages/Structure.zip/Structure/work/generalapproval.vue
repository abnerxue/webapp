<template>
  <div class="m-bg">
    <van-row class="m-header">
      <van-col span="2">
        <van-icon name="arrow-left" class="m-header-icon" @click="goback" />
      </van-col>
      <van-col span="1"></van-col>
      <van-col span="2">
        <van-icon name="cross" class="m-header-icon2" @click="gofirst" />
      </van-col>
      <van-col span="14">{{pageData.name}}</van-col>
      <van-col span="5">
        <div style="color:#00a2ff;font-size:0.35rem;">帮助</div>
      </van-col>
    </van-row>

    <!-- <div style="margin-top:1rem;width:100%">
      <div v-for="(item,index) in list" :key="index">
        <div  class="main">

        </div>
        {{item.name}}
      </div>
    </div> -->

    <van-cell-group style="margin-top:1.2rem">
      <van-field label="申请内容" placeholder="请输入申请内容">
        <van-icon class="iconfont" class-prefix="icon" name="jiufuqianbaoicon14" slot="left-icon" />
      </van-field>
    </van-cell-group>

    <van-cell-group style="margin-top:0.2rem">
      <van-field label="审批详情" :border="false">
        <van-icon class="iconfont" class-prefix="icon" name="jiufuqianbaoicon14" slot="left-icon" />
      </van-field>
      <van-field placeholder="请输入审批详情" type="textarea"></van-field>
    </van-cell-group>

    <van-cell-group style="margin-top:0.2rem">
      <van-field label="图片" :border="false" />
      <van-field placeholder="图片 后期修改" type="textarea">
        <van-icon name="plus" slot="left-icon" />
      </van-field>
    </van-cell-group>

    <van-cell-group style="margin-top:0.2rem">
      <van-field label="附件" :border="false" />
      <van-field placeholder="附件 后期修改" type="textarea">
        <van-icon name="plus" slot="left-icon" />
      </van-field>
    </van-cell-group>

    <van-cell-group style="margin-top:0.2rem">
      <div class="ss">
        <van-icon class="iconfont" class-prefix="icon" name="jiufuqianbaoicon14" />&nbsp;审批人
        <span style="font-size:0.12rem;color:#bcbcbc">&nbsp;流程未设置</span>
        <span style="font-size:0.12rem;color:#1989fa" @click="gohow">&nbsp;&nbsp;如何设置</span>
      </div>
      <!-- 选审批人 -->
      <div class="container">
        <div class="contain" v-for="(selitem,indexs) in sel_list_" :key="indexs">
          <div class="cross"><van-icon name="cross"/></div>
          <div class="round2">{{selitem.uName}}</div>
        </div>
        
        <!-- 加号 -->
        <div class="round"><van-icon name="plus" class="m-plus" @click="gochoose(1)"/></div>
      </div>
      <van-switch-cell v-model="checked" title="通过聊天发送给审批人" size="0.4rem" />
    </van-cell-group>

    <van-cell-group style="margin-top:0.2rem;margin-bottom:1.5rem">
      <div class="ss">
        <van-icon class="iconfont" class-prefix="icon" name="jiufuqianbaoicon14" />&nbsp;抄送人
        <span style="font-size:0.12rem;color:#bcbcbc">&nbsp;审批通过后，通知抄送人</span>
        <span style="font-size:0.12rem;color:#1989fa" @click="gohow2">&nbsp;&nbsp;如何设置</span>
      </div>
      <!-- 选抄送人 -->
      <div class="container">
        <div class="contain" v-for="(selitem,indexs) in sel_list" :key="indexs">
          <div class="cross"><van-icon name="cross"/></div>
          <div class="round2">{{selitem.uName}}</div>
        </div>
        
        <!-- 加号 -->
        <div class="round"><van-icon name="plus" class="m-plus" @click="gochoose(2)"/></div>
      </div>
    </van-cell-group>

    <div class="foot">
      <button class="btn" @click="popup">提交</button>
    </div>
    <van-dialog
  v-model="show"
  message="提交成功！"
  show-confirm-button
  @confirm="onConfirm"/>

  </div>
</template>
<script>
import Vue from "vue";
import global_ from "../../global"; //引用文件
Vue.prototype.GLOBAL = global_; //挂载到Vue实例上面
export default {
  data() {
    return {
      checked: false,
      pageData:'',
      list:[],
      show:false,
      uName:'',
      uId:'',
      namea:[],
      sel_list:'',
    };
  },
  methods: {
    top(){
      window.scrollTo(0,0);
      let data={
        uId:this.$route.query.uId,
        uName:this.$route.query.name,
      }
    },
    gohow() {
      this.$router.push("/setapproval");
    },
    gohow2() {
      this.$router.push("/setchaosong");
    },
    gofirst() {
      this.$router.push("/work");
    },
    goback() {
      this.$router.push("/approval");
    },
    gochoose(tag){
      sessionStorage.setItem('tag',tag);
      this.$router.push({
        path:'/choose',
        query:{
          id:this.$route.query.id
        }
        });
        
    },
    getList(){
      let _this=this;
      let data = {
        id:this.$route.query.id
      };

      this.pageData={
        id: 1,
        name: "通用审批",
        groupId: 1,
        icon: "",
        process: null,
        ccProcess: null,
        sort: 0,
        state: 1,
        ctime: "2019-07-22 09:32:56",
        utime: null
    }
      
      this.$ajax.post("cxt/oa/approval/temp",_this.$qs.stringify(data), {
          headers: _this.Base.initAjaxHeader(1, data)
        })
        .then(res=>{
          this.pageData=res.data.data;
          console.log(this.pageData);
          // this.list=JSON.parse(this.pageData.rule);
          // console.log(this.list);
        })
    },
    popup(){
      this.show=true;
    },
    onConfirm(){
      
        this.$router.push({
          path:"approval"
        })
    },
    getSelect(){
      let list = JSON.parse(sessionStorage.getItem('select_list'))?JSON.parse(sessionStorage.getItem('select_list')):'';
      let list_ = JSON.parse(sessionStorage.getItem('select_list_'))?JSON.parse(sessionStorage.getItem('select_list_')):'';
      this.sel_list = list;
      this.sel_list_ = list_;

    }
  },
  created() {
    this.getList();
    this.top();
    this.getSelect();

  },
  beforeUpdate(){
    this.namea.push(sessionStorage.getItem("namea"));
    console.log(this.namea)
  },
  beforeMount(){
    sessionStorage.setItem('namea',this.uName)
  }
};
</script>
<style scoped>
.m-bg {
  /* background-color: #ededed; */
  height: 100%;
}
.m-header {
  height: 1rem;
  line-height: 1rem;
  color: rgb(7, 7, 7);
  font-size: 0.4rem;
  background-color: white;
  position: fixed;
  top: 0;
  z-index: 2;
  width: 100%;
  text-align: center;
}

.m-header-icon {
  position: absolute;
  top: 0.3rem;
  left: 0.2rem;
  font-size: 0.5rem;
  color: #00a2ff;
}

.m-header-icon2 {
  position: absolute;
  top: 0.3rem;
  left: 1rem;
  font-size: 0.5rem;
  color: #00a2ff;
}

.ss {
  font-size: 0.32rem;
  padding-top: 0.2rem;
  margin-left: 0.3rem;
}

.foot {
  height: 1.1rem;
  width: 100%;
  position: fixed;
  bottom: 0;
  background-color: white;
  z-index:6;
}

.btn {
  background-color: #00a2ff;
  color: white;
  width: 96%;
  height: 0.9rem;
  margin: 0.15rem 2%;
  line-height: 0.9rem;
  text-align: center;
  
}

.round{
  width: 0.9rem;
  height: 0.9rem;
  border-radius: 0.9rem;
  line-height: 0.9rem;
  background-color: #ededed;
  text-align: center;
  display: inline-block;
  position: relative
}
.round2{
  width: 0.9rem;
  height: 0.9rem;
  border-radius: 0.9rem;
  line-height: 0.9rem;
  background-color: #00a2ff;
  text-align: center;
  color: white;
  
}
.contain{
  width: 0.9rem;
  height: 0.9rem;
  position: relative;
  display: inline-block;
  margin-right: 0.2rem
}
.cross{
  position: absolute;
  top:-0.05rem;
  right: -0.05rem;
  font-size: 0.04rem;
  z-index:5;
  background-color:black;
  color: white;
  width:0.35rem;
  height:0.35rem;
  border-radius: 0.35rem;
  text-align: center
}
.container{
  width:90%;
  margin: 0.3rem 5%;
  height:1rem
}

.m-plus{
  font-size: 0.5rem;
  position: absolute;
  top:21%;
  left:21%;
  color: #9a9a9a
}

.main{
  margin: 0.3rem 0 0.1rem 0.3rem;
  font-size: 0.3rem
}
</style>
